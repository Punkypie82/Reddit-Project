package dev.guruprasath.chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
