import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Items{
  String text;
  IconData icons;
  MaterialColor color;
  Items({required this.text,required this.icons,required this.color});
}