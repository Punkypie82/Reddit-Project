class User {
  String username;
  String password;
  String profilePictureUrl;

  User(this.username, this.password, this.profilePictureUrl);
}