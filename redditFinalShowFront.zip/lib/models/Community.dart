class Community {
  String name;
  String profileImage;
  String description;
  String backgroundImage;
  int memberCount;
  int onlineCount;

  Community(this.name, this.profileImage, this.description, this.backgroundImage, this.memberCount, this.onlineCount);
}