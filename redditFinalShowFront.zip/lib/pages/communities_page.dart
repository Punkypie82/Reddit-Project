import 'package:flutter/material.dart';

class RedditCommunitiesPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.lightBlue,
    );
  }

}