import 'package:flutter/material.dart';

class RedditPostPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.yellow,
    );
  }

}