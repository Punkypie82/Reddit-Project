import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:reddit/pages/comments_page.dart';
import 'package:reddit/pages/community_page.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/Post.dart';
import '../models/comment.dart';
import '../models/Community.dart';

class CommunityPageDes extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => CommunityPageDesState();
}

class CommunityPageDesState extends State {

  Community community = Community('nasa', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'r/NASA is for anything related to the National Aeronautics and Space Administration; the latest news, events, current and future missions, and more.', 'https://i.postimg.cc/T3S4fHw7/spacee-1920x1200.jpg', 1970693, 143);
  Comment comment = Comment('https://i.postimg.cc/XJ21qVkb/unnamed.jpg', "Rashin Rahnamun", '32m', 'wow this is awsome!!');
  late Post post = Post('assets/images/userImage2.jpeg', "assets/images/userImage1.jpeg", 'r/gifs', 'u/Amirhossein', '19h', 'Beautiful green walkway.', 'Nice beautiful day in nature.');

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 5,
      itemBuilder: (context, index) {
        upVote() {
          setState(() {
            post.upVoteEnabled ? post.upVoteEnabled = false : post.upVoteEnabled = true;
            if (post.downVoteEnabled && post.upVoteEnabled) {post.downVoteEnabled = false; post.upvotes++;}
            if (post.upVoteEnabled) post.upvotes++;
            else post.upvotes--;
          });
        }
        downVote() {
          setState(() {
            post.downVoteEnabled ? post.downVoteEnabled = false : post.downVoteEnabled = true;
            if (post.upVoteEnabled && post.downVoteEnabled) {post.upVoteEnabled = false; post.upvotes--;}
            if (post.downVoteEnabled) post.upvotes--;
            else post.upvotes++;
          });
        }
        return Container(
            color: const Color.fromARGB(255, 18, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Container(
                  height: 10.0,
                  color: Color.fromARGB(255, 9, 9, 9),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(15.0, 11.0, 10.0, 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            height: 40.0,
                            width: 40.0,
                            margin: const EdgeInsets.only(right: 7.0),
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: NetworkImage(post.profilePictureUrl)
                                )
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(post.subReddit, style: const TextStyle(color: Color.fromARGB(255, 215, 218, 220), fontWeight: FontWeight.w400)),

                              Text(post.username + " • " + post.date, style: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w300))
                            ],
                          )
                        ],
                      ),
                      const Icon(Icons.more_horiz, color: Colors.white60,)
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 10.0),
                  child: Text(post.title, style: const TextStyle(fontWeight: FontWeight.w500, color: Color.fromARGB(255, 215,218,220), fontSize: 20.0),),
                ),
                Row(
                  children: [
                    Expanded(
                        child: Image.network(
                          post.postUrl,
                          fit: BoxFit.cover,
                        )
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 10.0),
                  child: Linkify(
                    onOpen: (link) async {
                      if (await canLaunch(link.url)) {
                        await launch(link.url);
                      } else {
                        throw 'Could not launch $link';
                      }
                    },
                    text: post.description,
                    style: const TextStyle(color: Color.fromARGB(255, 215, 218, 220), fontWeight: FontWeight.w300, fontSize: 13.0),
                    linkStyle: const TextStyle(color: Colors.blueAccent),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(5.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          IconButton(onPressed: upVote, icon: post.upVoteEnabled ? Image.asset('assets/images/9.png', color: const Color.fromARGB(255, 255, 69, 0),) : Image.asset('assets/images/7.png', color: Colors.white60,), iconSize: 22),
                          Text(
                            post.upvotes.toString(),
                            style: TextStyle(
                              color: post.upVoteEnabled ? const Color.fromARGB(255, 255, 69, 0) : post.downVoteEnabled ? const Color.fromARGB(255, 113, 147, 225) : Colors.white60,
                            ),
                          ),
                          IconButton(onPressed: downVote, icon: post.downVoteEnabled ? Image.asset('assets/images/10.png', color: const Color.fromARGB(255, 113, 147, 225),) : Image.asset('assets/images/8.png', color: Colors.white60,), iconSize: 22,),
                        ],
                      ),
                      Row(
                        children: [
                         IconButton(onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => CommentsPage(post)));}, icon: Image.asset('assets/images/11.png', color: Colors.white60,), iconSize: 21),
                          IconButton(onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => CommunityPage()));}, icon: Image.asset('assets/images/11.png', color: Colors.white60,), iconSize: 21),
                          Text(post.commentsNum.toString(), style: const TextStyle(color: Colors.white60,),),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(onPressed: () {}, icon: const Icon(FontAwesomeIcons.arrowUpFromBracket, color: Colors.white60,), iconSize: 21),
                          const Text('Share', style: TextStyle(color: Colors.white60,),),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            )
        );
      }
    );
  }
}