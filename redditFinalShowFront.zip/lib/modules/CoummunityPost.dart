import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:reddit/components/communitiesList.dart';
import 'package:reddit/models/Communities.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../loginDetails.dart';
import '../reddit_Home_Page.dart';

class ChatPage2 extends StatefulWidget{
  String listShow="";
  String text;

  ChatPage2 ({required Key key,required this.text}) : super(key: key);
  String getText(){
    print(text);
    return this.text;
  }
  @override
  _ChatPageState2 createState() => _ChatPageState2(getText());
}


class _ChatPageState2 extends State<ChatPage2> {
  String text2;
  _ChatPageState2 (this.text2) {

      text2=this.text2;

  }


  @override
  Future<String> _initMessage()  async{
    String result="not";
      await Socket.connect("192.168.1.39", 6666).then((serverSocket){
        print('succesfull connection');
        serverSocket.write("ShowUserCommunity,"+loginDetails.username);
        serverSocket.flush();
        serverSocket.listen((response){
          result=String.fromCharCodes(response);
          print( result);
          widget.listShow=result;
          setState(() {});

        });

      });
    return result;


  }

  @override
  void initState() {
    super.initState();
    _initMessage().then((value) {
      setState(() {
        _isLoading = false;

        /*
        _users.addAll(value);
        _usersDisplay = _users;
        print(_usersDisplay.length);

         */
        print(_isLoading);
      });
    });
  }
/*
  Future<List<User>> fetchUsers() async{
    final http.Response response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      return compute(parseUser,response.body);
    } else {
      throw Exception(response.statusCode);
    }
  }

 */


  //var imageArray = [{'address':'images/userImage1.jpeg'}, {'address':'images/userImage2.jpeg'}, {'address':'images/userImage3.jpeg'}, {'address':'images/userImage4.jpeg'}, {'address':'images/userImage5.jpeg'}, {'address':'images/userImage6.jpeg'}, {'address':'images/userImage7.jpeg'}, {'address':'images/userImage8.jpeg'} ];
  //var intValue = Random().nextInt(10);
  //List<String> imgArr = ['images/userImage1.jpeg','images/userImage2.jpeg','images/userImage3.jpeg','images/userImage4.jpeg','images/userImage5.jpeg','images/userImage6.jpeg','images/userImage7.jpeg','images/userImage8.jpeg'
   // ];
 // var intValue = Random().nextInt(10);
 // String ranImg=imgArr[intValue];



  /*
  List<Communities> communities = [Communities(title:"r/iran", detail: "", image:"images/userImage1.jpeg" ),
    Communities(title: "r/reddit", detail: "", image: "images/userImage2.jpeg"),
    Communities(title: "r/flutter", detail: "", image: "images/userImage3.jpeg"),
    Communities(title: "r/ap", detail: "", image: "images/userImage4.jpeg"),
    Communities(title: "r/programming", detail: "", image: "images/userImage5.jpeg"),
    Communities(title: "r/project", detail: "", image: "images/userImage6.jpeg"),
    Communities(title: "r/SBU", detail: "", image: "images/userImage7.jpeg"),
    Communities(title: "r/national", detail: "?", image: "images/userImage8.jpeg")];
    */


  bool _isLoading = true;

  @override
  Future<String> _sendMyMessage(String comName)  async{
    if (comName.isNotEmpty) {
      await Socket.connect("192.168.1.39", 6666).then((serverSocket){
        //print('succesful connection');
        serverSocket.write("CreatePost,"+comName+","+widget.text+"\n");
        serverSocket.flush();
        serverSocket.listen((socket){
         // print(String.fromCharCodes(socket).trim().substring(2));
        });

      });
    }
    return "done";
  }



  Widget build(BuildContext context) {
    int z=0;
    /*
    while(z<8){
      communities.add(Communities(title: "r/reddit", detail: "", image: "images/userImage2.jpeg"));
    }
    */

    String testText=widget.listShow;
    late int count='\n'.allMatches(testText).length;
    var parts=testText.split(new RegExp(",|\n"));
    print("showTest"+count.toString());
    print("showTest2");
    print(parts.length);
    List<Communities> communities = [
      for(int i=1;i<count*2;i++)

        if(i%2==0 )
          Communities(title:parts[i-1], detail: "", image:"images/userImage2.jpeg" )

    ];



   // print(widget.listShow.split(","));
    return Scaffold(
      backgroundColor: Color.fromRGBO(26, 26, 27,1) ,
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[

            ListView.builder(
              itemCount:communities.length,
              shrinkWrap: true,
              padding: EdgeInsets.only(top: 16),
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index){

    if (_isLoading) {
      return GestureDetector(
        onTap: () async {
          Navigator.push(
              context, MaterialPageRoute(builder: (
              context) {
            return MyMainPage();

            //inja bas routing avaz she be shekl kanani  avaz
          }));
          _sendMyMessage(communities[index].title);
        },
        child: Container(
          padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 10),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Row(
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: AssetImage(communities[index].image),
                      maxRadius: 15,
                    ),
                    SizedBox(width: 16,),
                    Expanded(
                      child: Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(communities[index].title, style: TextStyle(
                                fontWeight: FontWeight.w400,
                                color: Colors.white)),

                            //SizedBox(height: 6,),
                            //Text(widget.secondaryText,style: TextStyle(fontSize: 14,color: Colors.grey.shade500),),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Text('',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),),
            ],
          ),
        ),
      );
    }
    else{
      return Text("loading...");
    }
                }





            ),
          ],
        ),
      ),
    );
  }
}