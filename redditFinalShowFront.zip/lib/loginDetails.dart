class loginDetails {

  static var username ="asghar";
  static var loggedIn = "Yes";

}