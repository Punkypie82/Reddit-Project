import 'package:flutter/material.dart';

class savedPosts extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text('Saved feed'),
          centerTitle: true,
          backgroundColor: Colors.black,
          
        ),
      );
}
