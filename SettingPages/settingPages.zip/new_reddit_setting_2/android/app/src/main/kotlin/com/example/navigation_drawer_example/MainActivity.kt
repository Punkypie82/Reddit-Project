package com.example.navigation_drawer_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
