import 'package:flutter/material.dart';

class RedditMessagePage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.indigoAccent,
    );
  }

}