import 'dart:io';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:reddit/loginDetails.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:reddit/models/Post.dart';

import '../models/comment.dart';

class CommentsPage extends StatefulWidget {

  final Post post;

  CommentsPage(this.post);

  @override
  State<StatefulWidget> createState() => CommentsPageState(post);
}

class CommentsPageState extends State<CommentsPage> {
  bool _isLoading = true;
  String listShow="";

  TextEditingController _commentController = TextEditingController();

  final Post post;
  CommentsPageState(this.post);
  Future<String> _initMessage()  async{
    String result="not";
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("showComment,"+this.post.title);
      serverSocket.flush();
      serverSocket.listen((response){
        result=String.fromCharCodes(response);
        print( result);
        listShow=result;
       // setState(() {});

      });

    });
    return result;


  }
  @override
  Future<String> _sendComment()  async{
    if (_commentController.text.isNotEmpty) {
      await Socket.connect("192.168.1.39", 6666).then((serverSocket){
        //print('succesful connection');
        serverSocket.write("postComment,"+loginDetails.username+","+ _commentController.text+","+this.post.title);
        serverSocket.flush();
        serverSocket.listen((socket){
          // print(String.fromCharCodes(socket).trim().substring(2));
        });

      });
    }
    return "done";
  }
//-1 or +1,commentMessage,userName
  Future<String> _sendLikeComment(String commentMessage)  async{

      await Socket.connect("192.168.1.39", 6666).then((serverSocket){
        //print('succesful connection');
        serverSocket.write("voteComment,"+"+1"+","+ commentMessage+","+loginDetails.username);
        serverSocket.flush();
        serverSocket.listen((socket){
          // print(String.fromCharCodes(socket).trim().substring(2));
        });

      });

    return "done";
  }


  //-1 or +1,commentMessage,userName
  Future<String> _sendDislikeComment(String commentMessage)  async{

    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      //print('succesful connection');
      serverSocket.write("voteComment,"+"-1"+","+ commentMessage+","+loginDetails.username);
      serverSocket.flush();
      serverSocket.listen((socket){
        // print(String.fromCharCodes(socket).trim().substring(2));
      });

    });

    return "done";
  }

  //-1 or +1,commentMessage,userName
  Future<String> _sendUpVote()  async{

    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      //print('succesful connection');
      serverSocket.write("votePost,"+"+1"+","+ this.post.title+","+loginDetails.username);
      serverSocket.flush();
      serverSocket.listen((socket){
        // print(String.fromCharCodes(socket).trim().substring(2));
      });

    });

    return "done";
  }

  //-1 or +1,commentMessage,userName
  Future<String> _sendDownVote()  async{

    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      //print('succesful connection');
      serverSocket.write("votePost,"+"-1"+","+ this.post.title+","+loginDetails.username);
      serverSocket.flush();
      serverSocket.listen((socket){
        // print(String.fromCharCodes(socket).trim().substring(2));
      });

    });

    return "done";
  }

  Future<int> _getVotes(String postTitle)  async{
    int result=0;
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("countVote,"+postTitle);
      serverSocket.flush();
      serverSocket.listen((response){
        result=int.parse(String.fromCharCodes(response));

        print( result);
        setState(() {});

      });

    });
    return result;


  }

  Future<int> _getCommentCount(String postTitle)  async{
    int result=0;
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("countComments,"+postTitle);
      serverSocket.flush();
      serverSocket.listen((response){
        result=int.parse(String.fromCharCodes(response));

        print( result);

        setState(() {});

      });

    });
    return result;


  }


  Future<int> _getVoteCommentCount(String commentTitle)  async{
    int result=0;
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("countVoteComment,"+commentTitle);
      serverSocket.flush();
      serverSocket.listen((response){
        result=int.parse(String.fromCharCodes(response));

        print( result);

        setState(() {});

      });

    });
    return result;


  }




  @override
  void initState() {
    super.initState();
    _initMessage().then((value) {
      setState(() {
        _isLoading = false;

        /*
        _users.addAll(value);
        _usersDisplay = _users;
        print(_usersDisplay.length);

         */
        print(_isLoading);
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    late int count='\n'.allMatches(listShow).length;
    var parts=listShow.split(new RegExp(",|\n"));
    print("showTest"+count.toString());
    print("showTest2");
    print(parts.length);


    List<Comment> comment = [
      for(int i=0;i<count*4-1;i+=4)
          Comment('https://i.postimg.cc/XJ21qVkb/unnamed.jpg', parts[i], parts[i+3], parts[i+1])

    ];
    List<Comment> comment2 = [
      for(int i=0;i<count*4-1;i+=4)
        Comment('https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg')

    ];

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(40.0), // here the desired height
        child: AppBar(
          backgroundColor: Colors.black,
          elevation: 0.0,
          actions: const [
            Padding(padding: EdgeInsets.only(top: 5.0), child: IconButton(onPressed: null, icon: Icon(Icons.notifications_none_outlined, color: Colors.white60,))),
            Padding(padding: EdgeInsets.only(top: 5.0), child: IconButton(onPressed: null, icon: Icon(Icons.more_horiz, color: Colors.white60,))),
          ],
        )
      ),
      body: ListView.builder(
        itemCount: comment.length,
        itemBuilder: (context, index) {
          if (!_isLoading) {

            loadData() async{
              post.upvotes = await _getVotes(post.title);
              post.commentsNum = await _getCommentCount(
                  post.title);

            }
            loadDataComment() async{
              comment[index].upvotes = await _getVoteCommentCount(comment[index].commentText);


            }

            //loadData();
            //loadDataComment();


            return index == 0 ?
            Container(
                color: const Color.fromARGB(255, 18, 18, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Container(
                      height: 10.0,
                      color: Color.fromARGB(255, 9, 9, 9),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          15.0, 11.0, 10.0, 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                height: 40.0,
                                width: 40.0,
                                margin: const EdgeInsets.only(right: 7.0),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                        image: NetworkImage(
                                            post.profilePictureUrl)
                                    )
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(post.subReddit, style: const TextStyle(
                                      color: Color.fromARGB(255, 215, 218, 220),
                                      fontWeight: FontWeight.w400)),

                                  Text(post.username + " • " + post.date,
                                      style: const TextStyle(
                                          color: Colors.white60,
                                          fontWeight: FontWeight.w300))
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 10.0),
                      child: Text(post.title, style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Color.fromARGB(255, 215, 218, 220),
                          fontSize: 20.0),),
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: Image.network(
                              post.postUrl,
                              fit: BoxFit.cover,
                            )
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 10.0),
                      child: Linkify(
                        onOpen: (link) async {
                          if (await canLaunch(link.url)) {
                            await launch(link.url);
                          } else {
                            throw 'Could not launch $link';
                          }
                        },
                        text: post.description,
                        style: const TextStyle(
                            color: Color.fromARGB(255, 215, 218, 220),
                            fontWeight: FontWeight.w300,
                            fontSize: 13.0),
                        linkStyle: const TextStyle(color: Colors.blueAccent),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5.0, 0.0, 20.0, 0.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              IconButton(onPressed: () {
                                _sendUpVote();
                                setState(() {
                                  post.upChanger();
                                  if (post.upVoteEnabled &&
                                      post.downVoteEnabled) post.downChanger();
                                });
                              },
                                  icon: post.upVoteEnabled ? Image.asset(
                                    'assets/images/9.png',
                                    color: const Color.fromARGB(
                                        255, 255, 69, 0),) : Image.asset(
                                    'assets/images/7.png',
                                    color: Colors.white60,),
                                  iconSize: 22),
                              Text(
                                post.upvotes.toString(),
                                style: TextStyle(
                                  color: post.upVoteEnabled ? const Color
                                      .fromARGB(255, 255, 69, 0) : post
                                      .downVoteEnabled ? const Color.fromARGB(
                                      255, 113, 147, 225) : Colors.white60,
                                ),
                              ),
                              IconButton(onPressed: () {
                                _sendDownVote();
                                setState(() {
                                  post.downChanger();
                                  if (post.upVoteEnabled &&
                                      post.downVoteEnabled) post.upChanger();
                                });
                              },
                                icon: post.downVoteEnabled ? Image.asset(
                                  'assets/images/10.png',
                                  color: const Color.fromARGB(
                                      255, 113, 147, 225),) : Image.asset(
                                  'assets/images/8.png',
                                  color: Colors.white60,),
                                iconSize: 22,),
                            ],
                          ),
                          Row(
                            children: [
                              Padding(padding: EdgeInsets.only(right: 8.0),
                                child: Image.asset('assets/images/11.png',
                                    color: Colors.white60),),
                              Text(post.commentsNum.toString(),
                                style: const TextStyle(
                                  color: Colors.white60,),),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(onPressed: () {},
                                  icon: const Icon(
                                    FontAwesomeIcons.arrowUpFromBracket,
                                    color: Colors.white60,),
                                  iconSize: 21),
                              const Text('Share',
                                style: TextStyle(color: Colors.white60,),),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
            ) :
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            Container(
                color: const Color.fromARGB(255, 18, 18, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Container(
                      height: 10.0,
                      color: Color.fromARGB(255, 9, 9, 9),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          15.0, 11.0, 10.0, 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                height: 40.0,
                                width: 40.0,
                                margin: const EdgeInsets.only(right: 7.0),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                        image: NetworkImage(
                                            comment[index].profilePictureUrl)
                                    )
                                ),
                              ),
                              Text(comment[index].name + " • " +
                                  comment[index].date, style: const TextStyle(
                                  color: Colors.white60,
                                  fontWeight: FontWeight.w300))
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(25.0, 0.0, 0.0, 10.0),
                      child: Linkify(
                        onOpen: (link) async {
                          if (await canLaunch(link.url)) {
                            await launch(link.url);
                          } else {
                            throw 'Could not launch $link';
                          }
                        },
                        text: comment[index].commentText,
                        style: const TextStyle(
                            color: Color.fromARGB(255, 215, 218, 220),
                            fontWeight: FontWeight.w300,
                            fontSize: 13.0),
                        linkStyle: const TextStyle(color: Colors.blueAccent),
                      ),
                    ),
                    Padding(


                        //loadDataComment();


                      padding: const EdgeInsets.fromLTRB(5.0, 0.0, 20.0, 0.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(onPressed: () {},
                              icon: const Icon(
                                Icons.more_horiz, color: Colors.white60,),
                              iconSize: 21),
                          Row(
                            children: [
                              IconButton(
                                  onPressed: () {},
                                  icon: Transform(
                                    alignment: Alignment.center,
                                    transform: Matrix4.rotationY(
                                        3.141592653589793),
                                    child: const Icon(FontAwesomeIcons.share,
                                      color: Colors.white60,),
                                  ),
                                  iconSize: 21
                              ),
                              const Text('Reply',
                                style: TextStyle(color: Colors.white60,),),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(onPressed: () {
                                _sendLikeComment(comment[index].commentText);
                                setState(() {
                                  comment[index].upChanger();
                                  if (comment[index].upVoteEnabled &&
                                      comment[index]
                                          .downVoteEnabled) comment[index].downChanger();
                                });
                              },
                                  icon: comment[index].upVoteEnabled ? Image
                                      .asset('assets/images/9.png',
                                    color: const Color.fromARGB(
                                        255, 255, 69, 0),) : Image.asset(
                                    'assets/images/7.png',
                                    color: Colors.white60,),
                                  iconSize: 22),
                              Text(
                                comment[index].upvotes.toString(),
                                style: TextStyle(
                                  color: comment[index].upVoteEnabled
                                      ? const Color.fromARGB(255, 255, 69, 0)
                                      : comment[index].downVoteEnabled
                                      ? const Color.fromARGB(255, 113, 147, 225)
                                      : Colors.white60,
                                ),
                              ),

                              IconButton(onPressed: () {
                                _sendDislikeComment(comment[index].commentText);
                                setState(() {
                                  comment[index].downChanger();
                                  if (comment[index].upVoteEnabled &&
                                      comment[index]
                                          .downVoteEnabled) comment[index]
                                      .upChanger();
                                });
                              },
                                icon: comment[index].downVoteEnabled ? Image
                                    .asset('assets/images/10.png',
                                  color: const Color.fromARGB(
                                      255, 113, 147, 225),) : Image.asset(
                                  'assets/images/8.png',
                                  color: Colors.white60,),
                                iconSize: 22,),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
            );
          }
          else{
            return Text("loading");
          }
        }
      ),
      bottomSheet: Container(
        padding: const EdgeInsets.only(left: 10, right: 1),
        color: const Color.fromARGB(255, 18, 18, 18),
        height: 55,
        child: TextFormField(
          controller: _commentController,
          decoration: InputDecoration(
            icon: Image.asset('assets/images/11.png', color: Colors.white60),
            labelText: 'Comment...',
            labelStyle:  TextStyle(color: Colors.white60,),
            suffixIcon:  IconButton(
              icon: Icon(Icons.send, size: 25, color: Colors.white60,),
              onPressed: ()  async{  _sendComment(); },
            ),
          ),
        ),
      ),
    );
  }
}