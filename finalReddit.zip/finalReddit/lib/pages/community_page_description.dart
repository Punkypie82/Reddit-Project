import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:reddit/loginDetails.dart';
import 'package:reddit/pages/comments_page.dart';
import 'package:reddit/pages/community_page.dart';
import 'package:url_launcher/url_launcher.dart';
import '../LatestCommunityPage.dart';
import '../models/Post.dart';
import '../models/comment.dart';
import '../models/Community.dart';

class CommunityPageDes extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => CommunityPageDesState();
}

class CommunityPageDesState extends State {
  String listShow="";
  String commentCountShow="";
  String voteCountShow="";
  bool _isLoading = true;
  @override
  Future<String> _initMessage()  async{
    String result="not";
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("showCommunityPost,"+LatestCommunityPage.latestName);
      serverSocket.flush();
      serverSocket.listen((response){
        result=String.fromCharCodes(response);
        print( result);
        listShow=result;
        setState(() {});

      });

    });
    return result;


  }
  Future<int> _getVotes(String postTitle)  async{
    int result=0;
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("countVote,"+postTitle);
      serverSocket.flush();
      serverSocket.listen((response){
        result=int.parse(String.fromCharCodes(response));

        print( result);
        setState(() {});

      });

    });
    return result;


  }

  Future<int> _getCommentCount(String postTitle)  async{
    int result=0;
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("countComments,"+postTitle);
      serverSocket.flush();
      serverSocket.listen((response){
        result=int.parse(String.fromCharCodes(response));

        print( result);

        setState(() {});

      });

    });
    return result;


  }

  @override
  Future<String> _deletePost(String postName,String ownerName)  async{
    if (LatestCommunityPage.latestCommunityOwner==loginDetails.username) {
      //deleteCommunityPost,community,postTitle,owner
      await Socket.connect("192.168.1.39", 6666).then((serverSocket){
        //print('succesful connection');
        serverSocket.write("deleteCommunityPost,"+LatestCommunityPage.latestName+","+postName+","+ownerName);
        serverSocket.flush();
        serverSocket.listen((socket){
          // print(String.fromCharCodes(socket).trim().substring(2));
        });

      });
    }
    return "done";
  }



  @override
  void initState() {
    super.initState();
    _initMessage().then((value) {
      setState(() {
        _isLoading = false;

        /*
        _users.addAll(value);
        _usersDisplay = _users;
        print(_usersDisplay.length);

         */
        print(_isLoading);
      });
    });
  }



  Community community = Community('nasa', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'r/NASA is for anything related to the National Aeronautics and Space Administration; the latest news, events, current and future missions, and more.', 'https://i.postimg.cc/T3S4fHw7/spacee-1920x1200.jpg', 1970693, 143);
  Comment comment = Comment('https://i.postimg.cc/XJ21qVkb/unnamed.jpg', "Rashin Rahnamun", '32m', 'wow this is awsome!!');
  //late Post post = Post('assets/images/userImage2.jpeg', "assets/images/userImage1.jpeg", 'r/gifs', 'u/Amirhossein', '19h', 'Beautiful green walkway.', 'Nice beautiful day in nature.');

  @override
  Widget build(BuildContext context) {
    late int count='\n'.allMatches(listShow).length;
    var parts=listShow.split(new RegExp(",|\n"));
    print("showTest"+count.toString());
    print("showTest8");
    print(parts.length);
    List<Post> posts = [
      for(int i=0;i<count*4;i+=4)
        Post('assets/images/userImage2.jpeg', "assets/images/userImage1.jpeg", parts[i],parts[i+3], '19h', parts[i+1], parts[i+2])

    ];
    List<Comment> comment2 = [
      for(int i=0;i<count*4-1;i+=4)
        Comment('https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg', 'https://i.postimg.cc/XJ21qVkb/unnamed.jpg')

    ];

    return ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          //normal feed
          if (!_isLoading) {
            loadData() async {
              posts[index].upvotes = await _getVotes(posts[index].title);
              posts[index].commentsNum = await _getCommentCount(
                  posts[index].title);
            }
            //loadData();
            upVote() {
              setState(() {
                posts[index].upVoteEnabled ?  posts[index].upVoteEnabled = false :  posts[index]
                    .upVoteEnabled = true;
                if ( posts[index].downVoteEnabled &&  posts[index].upVoteEnabled) {
                  posts[index].downVoteEnabled = false;
                  posts[index].upvotes++;
                }
                if ( posts[index].upVoteEnabled)
                  posts[index].upvotes++;
                else
                  posts[index].upvotes--;
              });
            }
            downVote() {
              setState(() {
                posts[index].downVoteEnabled ?  posts[index].downVoteEnabled = false :  posts[index]
                    .downVoteEnabled = true;
                if ( posts[index].upVoteEnabled &&  posts[index].downVoteEnabled) {
                  posts[index].upVoteEnabled = false;
                  posts[index].upvotes--;
                }
                if ( posts[index].downVoteEnabled)
                  posts[index].upvotes--;
                else
                  posts[index].upvotes++;
              });
            }
            return Container(
                color: const Color.fromARGB(255, 18, 18, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Container(
                      height: 10.0,
                      color: Color.fromARGB(255, 9, 9, 9),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          15.0, 11.0, 10.0, 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                height: 40.0,
                                width: 40.0,
                                margin: const EdgeInsets.only(right: 7.0),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                        image: NetworkImage(
                                            posts[index].profilePictureUrl)
                                    )
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text( posts[index].subReddit, style: const TextStyle(
                                      color: Color.fromARGB(255, 215, 218, 220),
                                      fontWeight: FontWeight.w400)),

                                  Text( posts[index].username + " • " +  posts[index].date,
                                      style: const TextStyle(
                                          color: Colors.white60,
                                          fontWeight: FontWeight.w300))
                                ],
                              )
                            ],
                          ),
                          const Icon(Icons.more_horiz, color: Colors.white60,)
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 10.0),
                      child: Text( posts[index].title, style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Color.fromARGB(255, 215, 218, 220),
                          fontSize: 20.0),),
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: Image.network(
                              posts[index].postUrl,
                              fit: BoxFit.cover,
                            )
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 10.0),
                      child: Linkify(
                        onOpen: (link) async {
                          if (await canLaunch(link.url)) {
                            await launch(link.url);
                          } else {
                            throw 'Could not launch $link';
                          }
                        },
                        text:  posts[index].description,
                        style: const TextStyle(
                            color: Color.fromARGB(255, 215, 218, 220),
                            fontWeight: FontWeight.w300,
                            fontSize: 13.0),
                        linkStyle: const TextStyle(color: Colors.blueAccent),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5.0, 0.0, 20.0, 0.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              IconButton(onPressed: upVote,
                                  icon:  posts[index].upVoteEnabled
                                      ? Image.asset('assets/images/9.png',
                                    color: const Color.fromARGB(
                                        255, 255, 69, 0),)
                                      : Image.asset('assets/images/7.png',
                                    color: Colors.white60,),
                                  iconSize: 22),
                              Text(
                                posts[index].upvotes.toString(),
                                style: TextStyle(
                                  color:  posts[index].upVoteEnabled ? const Color
                                      .fromARGB(255, 255, 69, 0) :  posts[index]
                                      .downVoteEnabled ? const Color.fromARGB(
                                      255, 113, 147, 225) : Colors.white60,
                                ),
                              ),
                              IconButton(onPressed: downVote,
                                icon:  posts[index].downVoteEnabled ? Image.asset(
                                  'assets/images/10.png',
                                  color: const Color.fromARGB(
                                      255, 113, 147, 225),) : Image.asset(
                                  'assets/images/8.png',
                                  color: Colors.white60,),
                                iconSize: 22,),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(onPressed: () {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => CommentsPage( posts[index])));
                              },
                                  icon: Image.asset('assets/images/11.png',
                                    color: Colors.white60,),
                                  iconSize: 21),
                              IconButton(onPressed: () {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => CommunityPage()));
                              },
                                  icon: Image.asset('assets/images/11.png',
                                    color: Colors.white60,),
                                  iconSize: 21),
                              Text( posts[index].commentsNum.toString(),
                                style: const TextStyle(
                                  color: Colors.white60,),),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(onPressed: () async {
                                if(loginDetails.username==LatestCommunityPage.latestCommunityOwner)
                                _deletePost(posts[index].title,posts[index].username);

                              }, icon: const Icon(
                                FontAwesomeIcons.arrowUpFromBracket,
                                color: Colors.white60,), iconSize: 21),
                              if(loginDetails.username==LatestCommunityPage.latestCommunityOwner)
                              const Text('Delete', style: TextStyle(
                                color: Colors.white60,),),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
            );
          }
          else{
            return Text("loading....");
          }
        }
    );
  }
}