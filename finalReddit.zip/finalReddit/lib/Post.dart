class Post {
  String subReddit;
  String username;
  String date;
  String title;
  String profilePictureUrl;
  String postUrl;
  int upvotes = 0;
  int commentsNum = 0;
  bool upVoteEnabled = false;
  bool downVoteEnabled = false;

  Post(this.profilePictureUrl, this.postUrl, this.subReddit, this.username, this.date, this.title);

  void upChanger() {this.upVoteEnabled ? this.upVoteEnabled = false : this.upVoteEnabled = true;}

  void downChanger() {downVoteEnabled ? downVoteEnabled = false : downVoteEnabled = true;}

  bool getUpVoteEnabled() {return upVoteEnabled;}

  downVote() {
    downVoteEnabled ? downVoteEnabled = false : downVoteEnabled = true;
    if (upVoteEnabled && downVoteEnabled) upVoteEnabled = false;
  }
}