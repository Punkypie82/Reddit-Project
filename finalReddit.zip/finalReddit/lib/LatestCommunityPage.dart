class LatestCommunityPage {

  static var latestName ="";
  static var latestCommunityOwner ="";


}