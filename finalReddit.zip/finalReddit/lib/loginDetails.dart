class loginDetails {

  static var username ="owner";
  static var loggedIn = "Yes";

}