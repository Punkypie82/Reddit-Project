import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:reddit/components/communitiesList.dart';
import 'package:reddit/models/Communities.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../loginDetails.dart';
import '../pages/community_page.dart';
import 'UploadPostPage.dart';

class ChatPage extends StatefulWidget{
  String listShow="";



  @override
  _ChatPageState createState() => _ChatPageState();
}


class _ChatPageState extends State<ChatPage> {



  @override
  Future<String> _initMessage()  async{
    String result="not";
    await Socket.connect("192.168.1.39", 6666).then((serverSocket){
      print('succesfull connection');
      serverSocket.write("ShowCommunities,Okey");
      serverSocket.flush();
      serverSocket.listen((response){
        result=String.fromCharCodes(response);
        print( result);
        widget.listShow=result;
        setState(() {});

      });

    });
    return result;


  }

  @override
  void initState() {
    super.initState();
    _initMessage().then((value) {
      setState(() {
        _isLoading = false;

        /*
        _users.addAll(value);
        _usersDisplay = _users;
        print(_usersDisplay.length);

         */
        print(_isLoading);
      });
    });
  }



  bool _isLoading = true;



  Widget build(BuildContext context) {

    String testText=widget.listShow;
    late int count='\n'.allMatches(testText).length;
    var parts=testText.split(new RegExp(",|\n"));
    print("showTest"+count.toString());
    print("showTest2");
    print(parts.length);
    List<Communities> communities = [
      for(int i=1;i<count*2+1;i++)

        if(i%2==0 )
          Communities(title:parts[i-1], detail: "", image:"images/userImage2.jpeg" )

    ];
    List<Communities> communities2 = [
    Communities(title:"me", detail: "", image:"images/userImage2.jpeg" ),
      Communities(title:"me", detail: "", image:"images/userImage3.jpeg" ),
      Communities(title:"me", detail: "", image:"images/userImage4.jpeg" ),


    ];
    // print(widget.listShow.split(","));
    return Scaffold(
      backgroundColor: Color.fromRGBO(26, 26, 27,1) ,
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 16,left: 16,right: 16),
              child: TextField(

                decoration: InputDecoration(
                  hintText: "Search...",
                  hintStyle: TextStyle(color: Colors.grey.shade400),
                  prefixIcon: Icon(Icons.search,color: Colors.grey.shade400,size: 20,),
                  filled: true,
                  fillColor: Color.fromRGBO(70, 72, 74,1),
                  contentPadding: EdgeInsets.all(8),
                  enabledBorder: OutlineInputBorder(
                    // borderRadius: BorderRadius.circular(30),

                  ),
                ),
              ),
            ),
            ListView.builder(
                itemCount:communities.length,
                shrinkWrap: true,
                padding: EdgeInsets.only(top: 16),
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index){

                  if (!_isLoading) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context, MaterialPageRoute(builder: (
                                  context) {
                                return CommunityPage();

                                //inja bas routing avaz she be shekl kanani  avaz
                              }));
                            },
                      child: Container(
                        padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 10),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                children: <Widget>[
                                  CircleAvatar(
                                    backgroundImage: AssetImage(communities[index].image),
                                    maxRadius: 15,
                                  ),
                                  SizedBox(width: 16,),
                                  Expanded(
                                    child: Container(
                                      color: Colors.transparent,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(communities[index].title, style: TextStyle(
                                              fontWeight: FontWeight.w400,
                                              color: Colors.white)),

                                          //SizedBox(height: 6,),
                                          //Text(widget.secondaryText,style: TextStyle(fontSize: 14,color: Colors.grey.shade500),),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text('',
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade500),),
                          ],
                        ),
                      ),
                    );
                  }
                  else{
                    return Text("loading...");
                  }
                }





            ),
          ],
        ),
      ),
    );
  }
}
