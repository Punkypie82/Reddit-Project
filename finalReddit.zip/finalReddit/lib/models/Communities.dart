import 'package:flutter/cupertino.dart';

class Communities{
  String title;
  String detail;
  String image;
  Communities({required this.title,required this.detail,required this.image});
}