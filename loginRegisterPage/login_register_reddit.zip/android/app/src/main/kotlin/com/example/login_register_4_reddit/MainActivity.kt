package com.example.login_register_4_reddit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
