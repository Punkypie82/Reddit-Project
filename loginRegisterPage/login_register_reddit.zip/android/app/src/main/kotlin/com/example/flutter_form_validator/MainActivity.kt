package com.example.flutter_form_validator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
