import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;



public class Core {
    static boolean serverOn=true;
    static int port=6666;
    public static void main(String[] args){
        try{

            ServerSocket ss= new ServerSocket(port);
            while( serverOn==true){
                Socket s=ss.accept();
                System.out.println("works...");
                serverThread st= new serverThread(s);
                st.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    static class serverThread extends Thread {
        Socket s;
        DataOutputStream dout;
        DataInputStream din;

        serverThread(Socket s) {
            this.s = s;
            try {
                din = new DataInputStream(s.getInputStream());
                dout = new DataOutputStream(s.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        String handeler() {
            StringBuilder num = new StringBuilder();
            StringBuilder str = new StringBuilder();

            char i;
            String line="";
            try {
                Scanner in = new Scanner(s.getInputStream());
                while (in.hasNextLine()){
                    //process each line in some way
                    line = in.nextLine();

                }
            } catch (IOException e) {
                try {
                    din.close();
                    dout.close();
                    s.close();

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            return line;
        }

        @Override
        public void run() {

                String ans = "nothing";
                String wStr = "nothing";
                //String input=handeler();
                String input = "Register,nana,nini,lopi";


                String[] inputArr = input.split(",");


                if (inputArr[0].equals("CreatePost")) {

                    wStr = inputArr[1] + "," + inputArr[2] + "," + inputArr[3]+"\n";
                    try {
                        FileWriter myWriter = new FileWriter("AddPost.txt", true);
                        myWriter.write(wStr);
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }

            if (inputArr[0].equals("CreateCommunity")) {
                 //input
                //CreateCommunity,owner,communityName
                wStr = inputArr[1] + "," + inputArr[2]+"\n" ;
                try {
                    FileWriter myWriter = new FileWriter("Communities.txt", true);
                    myWriter.write(wStr);
                    myWriter.close();
                    System.out.println("Successfully wrote to the file.");
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }
            if (inputArr[0].equals("favCommunity")) {
                //input
                //favCommunity,user,communityName,owner
                wStr = inputArr[1] + "," + inputArr[2] + inputArr[3]+"\n" ;
                try {
                    FileWriter myWriter = new FileWriter("favCommunities.txt", true);
                    myWriter.write(wStr);
                    myWriter.close();
                    System.out.println("Successfully wrote to the file.");
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }


                if (inputArr[0].equals("ShowUserCommunity")) {

                    String line = null;
                    String outPut = "";
                    try {
                        FileReader fileReader = new FileReader("FollowedCommunities.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {

                            if (line.contains(inputArr[1])) {

                                outPut += line + "\n";
                            }


                        }

                        // writer(outPut);
                        dout.writeBytes(outPut);
                        dout.flush();
                        dout.close();
                        System.out.println(outPut);

                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }
                }

            if (inputArr[0].equals("ShowFavCommunity")) {
                //ShowFavCommunity,user
                String line = null;
                String outPut = "";
                try {
                    FileReader fileReader = new FileReader("favCommunities.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains(inputArr[1])) {

                            outPut += line + "\n";
                        }


                    }

                    // writer(outPut);
                    dout.writeBytes(outPut);
                    dout.flush();
                    dout.close();
                    System.out.println(outPut);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }
            }


            if (inputArr[0].equals("searchCommunity")) {
                //searchCommunity,title
                String line = null;
                String outPut = "";
                try {
                    FileReader fileReader = new FileReader("Communities.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains(inputArr[1])) {

                            outPut += line + "\n";
                        }


                    }

                    // writer(outPut);
                    dout.writeBytes(outPut);
                    dout.flush();
                    dout.close();
                    System.out.println(outPut);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }
            }

            if (inputArr[0].equals("searchFeed")) {
                //searchFeed,keyword
                String line = null;
                String outPut = "";
                try {
                    FileReader fileReader = new FileReader("AddPost.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains(inputArr[1])) {

                            outPut += line + "\n";
                        }


                    }

                    // writer(outPut);
                    dout.writeBytes(outPut);
                    dout.flush();
                    dout.close();
                    System.out.println(outPut);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }
            }




                if (inputArr[0].equals("ShowCommunities")) {

                    String line = null;
                    String outPut = "";
                    try {
                        FileReader fileReader = new FileReader("Communities.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {
                            outPut += line + "\n";
                        }

                        // writer(outPut);
                        dout.writeBytes(outPut);
                        dout.flush();
                        dout.close();


                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }
                }
                if (inputArr[0].equals("votePost")) {
                    //-1 or +1,postTitle,userName
                    wStr = inputArr[1] + "," + inputArr[2] + "," + inputArr[3]+"\n";
                    try {
                        FileWriter myWriter = new FileWriter("votePost.txt", true);
                        myWriter.write(wStr);
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }
                if (inputArr[0].equals("voteComment")) {
                    //-1 or +1,commentMessage,userName
                    wStr = inputArr[1] + "," + inputArr[2] + "," + inputArr[3]+"\n";
                    try {
                        FileWriter myWriter = new FileWriter("voteComment.txt", true);
                        myWriter.write(wStr);
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }
                if (inputArr[0].equals("postComment")) {
                    //postComment,username,comment,postTitle
                    String username = inputArr[1];
                    String commment = inputArr[2];
                    String postTitle = inputArr[3];

                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy HH-mm-ss");
                    Date date = new Date();
                    String dateStr = dateFormat.format(date);
                    boolean userExists = true;

                    wStr = username + "," + commment + "," + postTitle + "," + dateStr + "\n";

                    try {
                        FileWriter myWriter = new FileWriter("comments.txt", true);
                        myWriter.write(wStr);
                        myWriter.flush();
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }
                //showPost must combine with comment and like and dislike per comments and per post
                if (inputArr[0].equals("showPost")) {
                    //showPost
                    //outputFile:
                    //community,title,description,user
                    String line = null;
                    String outPut = "";
                    try {
                        FileReader fileReader = new FileReader("AddPost.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {
                            outPut += line + "\n";
                        }

                        // writer(outPut);
                        dout.writeBytes(outPut);
                        dout.flush();
                        dout.close();


                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }

                }

                //showPost must combine with comment and like and dislike per comments and per post
                if (inputArr[0].equals("showCommunityPost")) {
                    //showCommunityPost,r/SBU
                    //outputFile:
                    //scommunity,title,description,user

                    String line = null;
                    String outPut = "";
                    try {
                        FileReader fileReader = new FileReader("AddPost.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {

                            if (line.contains(inputArr[1])) {

                                outPut += line + "\n";
                            }


                        }

                        // writer(outPut);
                        dout.writeBytes(outPut);
                        dout.flush();
                        dout.close();
                        System.out.println(outPut);

                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }

                }


                //showPost must combine with comment and like and dislike per comments and per post
                if (inputArr[0].equals("showSavedPost")) {
                    //showCommunityPost,r/SBU
                    //outputFile:
                    //showSavedPost,saveduser,title,description,user

                    String line = null;
                    String outPut = "";
                    try {
                        FileReader fileReader = new FileReader("savedPost.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {

                            if (line.contains(inputArr[1])) {
                                if (line.contains(inputArr[2])) {

                                    outPut += line + "\n";
                                }
                            }


                        }

                        // writer(outPut);
                        dout.writeBytes(outPut);
                        dout.flush();
                        dout.close();
                        System.out.println(outPut);

                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }

                }

                if (inputArr[0].equals("savePost")) {
                    //savePost,savedUser1,community,title,description,createdUser1
                    wStr = inputArr[1] + "," + inputArr[2] + "," + inputArr[3] + "," + inputArr[4] + "," + inputArr[5]+"\n";
                    try {
                        FileWriter myWriter = new FileWriter("savedPost.txt", true);
                        myWriter.write(wStr);
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }


            if (inputArr[0].equals("deleteCommunityPost")) {
                //deleteCommunityPost,community,postTitle,owner
                wStr = inputArr[1] + "," + inputArr[2] + "," + inputArr[3] ;
                File inputFile = new File("AddPost.txt");
                File tempFile = new File("TempAddPost.txt");

                BufferedReader reader = null;
                try {
                    reader = new BufferedReader(new FileReader(inputFile));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                BufferedWriter writer = null;
                try {
                    writer = new BufferedWriter(new FileWriter(tempFile));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                String lineToRemove = wStr;
                String currentLine = null;

                while(true) {
                    try {
                        if (!((currentLine = reader.readLine()) != null)) break;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // trim newline when comparing with lineToRemove
                    String trimmedLine = currentLine.trim();
                    if(trimmedLine.equals(lineToRemove)) continue;
                    try {
                        writer.write(currentLine + System.getProperty("line.separator"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                boolean successful = tempFile.renameTo(inputFile);
                System.out.println("succesfully deleted");

                FileInputStream inputStream  = null;
                try {
                    inputStream = new FileInputStream(tempFile);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                FileOutputStream outputStream  = null;
                try {
                    outputStream = new FileOutputStream(inputFile);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                // use try-catch-finally block to read and write bytes data into file
                try {
                    // declare variable for indexing
                    int i;

                    while ((i = inputStream.read()) != -1) {


                        outputStream.write(i);
                    }
                }

                catch(Exception e) {
                    System.out.println("Error Found: "+e.getMessage());
                }

                finally {
                    if (inputStream != null) {

                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                System.out.println("File Copied");




            }



                if (inputArr[0].equals("followCommunity")) {
                    //followCommunity,user,community
                    wStr = inputArr[1] + "," + inputArr[2]+"\n";
                    try {
                        FileWriter myWriter = new FileWriter("FollowedCommunities.txt", true);
                        myWriter.write(wStr);
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }

                //showPost must combine with comment and like and dislike per comments and per post
                if (inputArr[0].equals("countComments")) {
                    //countComments,post_title
                    //outputFile:
                    //number

                    String line = null;
                    String outPut = "";
                    int counter=0;
                    try {
                        FileReader fileReader = new FileReader("comments.txt");

                        // always wrap the FileReader in BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        while ((line = bufferedReader.readLine()) != null) {

                            if (line.contains(","+inputArr[1]+",")) {

                               counter += 1;
                            }


                        }

                        // writer(outPut);
                        dout.write(counter);
                        dout.flush();
                        dout.close();
                        System.out.println(counter);

                        // always close the file after its use
                        bufferedReader.close();
                    } catch (IOException ex) {
                        System.out.println("\nError occurred");
                        System.out.println("Exception Name: " + ex);
                    }

                }

            //showPost must combine with comment and like and dislike per comments and per post
            if (inputArr[0].equals("countUpVotePost")) {
                //countUpVotePost,post_title
                //outputFile:
                //number

                String line = null;
                String outPut = "";
                int counter=0;
                try {
                    FileReader fileReader = new FileReader("votePost.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains("+1,"+inputArr[1])) {

                            counter += 1;
                        }


                    }

                    // writer(outPut);
                    dout.write(counter);
                    dout.flush();
                    dout.close();
                    System.out.println(counter);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }

            }
            //showPost must combine with comment and like and dislike per comments and per post
            if (inputArr[0].equals("countdownVotePost")) {
                //countdownVotePost,post_title
                //outputFile:
                //number

                String line = null;
                String outPut = "";
                int counter=0;
                try {
                    FileReader fileReader = new FileReader("votePost.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains("-1,"+inputArr[1])) {

                            counter += 1;
                        }


                    }

                    // writer(outPut);
                    dout.write(counter);
                    dout.flush();
                    dout.close();
                    System.out.println(counter);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }

            }

            //showPost must combine with comment and like and dislike per comments and per post
            if (inputArr[0].equals("countUpVoteComment")) {
                //countUpVoteComment,commentMessage
                //outputFile:
                //number

                String line = null;
                String outPut = "";
                int counter=0;
                try {
                    FileReader fileReader = new FileReader("voteComment.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains("+1,"+inputArr[1])) {

                            counter += 1;
                        }


                    }

                    // writer(outPut);
                    dout.write(counter);
                    dout.flush();
                    dout.close();
                    System.out.println(counter);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }

            }
            //showPost must combine with comment and like and dislike per comments and per post
            if (inputArr[0].equals("countdownVoteComment")) {
                //countdownVoteComment,commentMessage
                //outputFile:
                //number

                String line = null;
                String outPut = "";
                int counter=0;
                try {
                    FileReader fileReader = new FileReader("voteComment.txt");

                    // always wrap the FileReader in BufferedReader
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    while ((line = bufferedReader.readLine()) != null) {

                        if (line.contains("-1,"+inputArr[1])) {

                            counter += 1;
                        }


                    }

                    // writer(outPut);
                    dout.write(counter);
                    dout.flush();
                    dout.close();
                    System.out.println(counter);

                    // always close the file after its use
                    bufferedReader.close();
                } catch (IOException ex) {
                    System.out.println("\nError occurred");
                    System.out.println("Exception Name: " + ex);
                }

            }

            if (inputArr[0].equals("Register")) {
                //Register,username, password,email

                String id = inputArr[1] + inputArr[2];
                String username = inputArr[1];
                String password = inputArr[2];
                String email = inputArr[3];
                boolean usernameExists = false;
                boolean emailExists = false;

                try {
                    BufferedReader reader = new BufferedReader(new FileReader("users.txt"));

                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        if (username.equals( line.split(",")[1])) {usernameExists = true;}
                        if (email.equals(line.split(",")[3])) {emailExists = true;}
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (emailExists && usernameExists) {
                    try {
                        dout.writeBytes("Email & Username Exists.");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Email & Username Exists");
                }
                else if (usernameExists && !(emailExists)) {
                    try {
                        dout.writeBytes("Username Exists");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Username Exists");
                }
                else if (emailExists && !(usernameExists)) {
                    try {
                        dout.writeBytes("Email Exists");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Email Exists");
                }
                else if (!(emailExists) && !(usernameExists)) {
                    try {
                        dout.writeBytes("User Created");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("User Created");

                    wStr = id + "," + username + "," + password + "," + email + "\n";
                    System.out.println(wStr);
                    try {
                        FileWriter myWriter = new FileWriter("users.txt", true);
                        myWriter.write(wStr);
                        myWriter.flush();
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }
            }

            if (inputArr[0].equals("Login")) {
                //Login,username,password
                String id = inputArr[1] + inputArr[2];
                String username = inputArr[1];
                String password = inputArr[2];
                boolean userExists = false;

                try {
                    BufferedReader reader = new BufferedReader(new FileReader("users.txt"));
                    String line = "";


                    while ((line = reader.readLine()) != null) {
                        if (line.contains(id)) {


                            userExists = true;}
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (userExists) {
                    try {
                        dout.writeBytes("Login Successful");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Login Successful");
                }
                else {
                    try {
                        dout.writeBytes("Login Failed");
                        dout.flush();
                        dout.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Login Failed");
                }
            }





        }

            }







}


